-- this file is not a valid lua file

function test()
    if true
        print("test")
    end
end


for i=1,10 do
    print("test2")